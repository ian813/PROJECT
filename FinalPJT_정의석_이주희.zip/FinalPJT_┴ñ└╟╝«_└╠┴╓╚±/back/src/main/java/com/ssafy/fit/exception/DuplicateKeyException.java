package com.ssafy.fit.exception;

public class DuplicateKeyException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DuplicateKeyException(String msg) {
		super(msg);
	}

}
