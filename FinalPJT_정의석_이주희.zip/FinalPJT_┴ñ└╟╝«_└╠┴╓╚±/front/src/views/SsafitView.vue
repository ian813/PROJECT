<template>
  <div>
    <ssafit-main></ssafit-main>
  </div>
</template>

<script>
import SsafitMain from '@/components/ssafit/SsafitMain.vue';

export default {
  name: 'SsafitView',
  components: {
    SsafitMain,
  },
};
</script>

<style scoped>
h2 {
  color: red;
}
</style>
