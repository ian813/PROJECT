<template>
    <div>
      <router-view />
    </div>
  </template>
  
<script>
  export default {
    name: "UserView",
  };
</script>
  
<style>

</style>
  