<template>
  <div>
    <img src="@/assets/ssafitboard.jpg"/>
  </div>
</template>
  
<script>
  export default {
  
  }
</script>
  
<style>
  
</style>
  