<template>
  <div>
    <img src="@/assets/ssafitnav.jpg"/>
  </div>
</template>
  
<script>
  export default {
  
  }
</script>
  
<style>
  
</style>
  