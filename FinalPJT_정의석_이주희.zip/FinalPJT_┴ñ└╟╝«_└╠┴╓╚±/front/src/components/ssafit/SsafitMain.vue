<template>
    <div>
        <ssafit-search></ssafit-search>
        <BackgroundNav></BackgroundNav>
    </div>
</template>

<script>
import SsafitSearch from './SsafitSearch.vue';
import BackgroundNav from '../common/BackgroundNav.vue';

export default {

components: {
    SsafitSearch,
    BackgroundNav,
  }
}

</script>

<style>

</style>