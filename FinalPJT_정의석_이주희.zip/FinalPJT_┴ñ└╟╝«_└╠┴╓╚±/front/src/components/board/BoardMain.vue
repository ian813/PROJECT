<template>
  <div>
    <!-- board 불러오기  -->
    <board/>
  </div>
</template>

<script>

import Board from './Board.vue';

export default {

components: {
  Board,
  }
}

</script>

<style>

</style>